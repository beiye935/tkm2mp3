self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f2a5ea9acb7b6e8d71d5",
    "url": "css/app.7c15f6b3.css"
  },
  {
    "revision": "33d12a78ab71406c1b57",
    "url": "css/chunk-vendors.094863c6.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "5aa4772c6d13c47381e7f00b35bdfd46",
    "url": "index.html"
  },
  {
    "revision": "cfce103133e001de644ebb74900ec950",
    "url": "js/0.bb00e0b9.worker.js"
  },
  {
    "revision": "f2a5ea9acb7b6e8d71d5",
    "url": "js/app.ec20e22f.js"
  },
  {
    "revision": "33d12a78ab71406c1b57",
    "url": "js/chunk-vendors.5db7ca01.js"
  },
  {
    "revision": "02995355b96ddf2519cd49f8aa73bb46",
    "url": "loader.js"
  },
  {
    "revision": "cd1d395410107c66b4534ec93f0073d3",
    "url": "web-manifest.json"
  }
]);